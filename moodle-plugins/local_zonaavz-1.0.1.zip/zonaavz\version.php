<?php

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_zonaavz';
$plugin->version = 2026071400;
$plugin->requires = 2015111600;
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.0.1';
$plugin->dependencies = array(
    'local_mail' => 2017121405,
);
